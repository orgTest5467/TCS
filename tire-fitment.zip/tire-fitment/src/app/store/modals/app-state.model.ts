import { ShoppingState } from '../reducers/tiredata.reducer';

export interface AppState {
  readonly shopping: ShoppingState
}